import React from "react";
import {Button} from "antd";

export class CartFooter extends React.Component{
    render() {
        return(
            <div className={"cartfooter"}>
                <Button className={"cartbutton"}>结算订单</Button>
            </div>
        )
    }
}
