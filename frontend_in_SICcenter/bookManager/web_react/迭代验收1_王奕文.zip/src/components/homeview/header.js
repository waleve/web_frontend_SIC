import React from "react";

export class  Header extends React.Component
{
    render() {
        return(
            <div className="header">
                <h1>BOOKSTORE</h1>
                <p>天堂是图书馆模样</p>
            </div>
        )
    }
}
