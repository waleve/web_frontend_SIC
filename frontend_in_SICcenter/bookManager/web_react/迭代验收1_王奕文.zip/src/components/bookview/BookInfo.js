import React from "react";
import {Headerbar} from "../Headerbar";
import {Link} from "react-router-dom";

export class BookInfo extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            name:this.props.name,
            author:this.props.author,
            img:this.props.image,
            prcie:this.props.price,
            language:this.props.language,
            edit:null,
            idx:this.props.idx,
        };
    }

    showEditor = (e) => {
        this.setState({edit:1});
    };

    save = (e) => {
        e.preventDefault();
        let input = e.target.firstChild;
        let data = this.state.author.slice();
        data = input.value;
        this.setState({
            edit: null,
            author: data,
        });
    };

    renderAuthor =()=>{
        if (this.state.edit === 1)
        {
            return<form onSubmit={this.save}><input type={"text"} /></form>
        }else{
            return <div>作者：{this.state.author}</div>;
        }
    }


    render() {
        return(
            <div>
                <Headerbar/>
                <div className={"book-detail"}>
                    <div>
                        <img src={this.state.img} height={"320px"} className={"bookphoto"}/>
                    </div>
                    <div onDoubleClick={this.showEditor}>
                        {this.renderAuthor()}
                    </div>
                    <div>
                        名称：{this.state.name}
                    </div>
                    <div>
                        {this.state.price}
                    </div>
                </div>
                <button className={"bookbutton"}>添加到购物车</button>
                <Link to={"/Order/" + this.props.idx}>
                    <button className={"bookbutton"}>立即购买</button>
                </Link>
            </div>

        )
    }


}
